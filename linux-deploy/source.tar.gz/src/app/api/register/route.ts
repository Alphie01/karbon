import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import bcrypt from "bcryptjs";

export async function POST(req: Request) {
    try {
        const { name, email, password } = await req.json();

        if (!email || !password) {
            return NextResponse.json(
                { message: "E-posta ve şifre gereklidir." },
                { status: 400 }
            );
        }

        const existingUser = await prisma.user.findUnique({
            where: { email },
        });

        if (existingUser) {
            return NextResponse.json(
                { message: "Bu e-posta adresi zaten kullanılıyor." },
                { status: 400 }
            );
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        const user = await prisma.user.create({
            data: {
                name,
                email,
                password: hashedPassword,
                roles: "STUDENT",
            },
        });

        return NextResponse.json({ message: "Kayıt başarılı." }, { status: 201 });
    } catch (error) {
        return NextResponse.json(
            { message: "Bir hata oluştu.", error },
            { status: 500 }
        );
    }
}
